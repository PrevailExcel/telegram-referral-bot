<?php

namespace App\Services;

use App\Models\User;

class UserService
{
    public function createAndReward($referral, $bot)
    {
        $referralId = $bot->getUser()->getId();

        // Check if Referrer exists
        $referrer = User::whereReferrerId($referral)->first();
        if ($referrer) {

            // Create User if he doesn't exist
            $user = User::whereReferalId($referralId)->exists();

            if (!$user)
                $user = User::create([
                    'name' => $bot->getUser()->getUsername(),
                    'referrer_id' => $referral,
                    'referral_id' => $referralId
                ]);

            // Reward Referrer
            $referrer->increment('points', 100);
            $referrer->save();

            $data = [
                'link' => $this->generateReferralLink($referralId),
                'referrer_points' => $referrer->points
            ];

            return $data;
        } else
            return false;
    }

    public function generateReferralLink($userId)
    {
        $telegramUsername = 'YourBotUsername';
        $referralLink = "https://t.me/$telegramUsername?start=$userId";

        return $referralLink;
    }
}
